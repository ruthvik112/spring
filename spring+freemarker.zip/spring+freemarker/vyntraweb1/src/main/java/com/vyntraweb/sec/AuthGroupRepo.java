package com.vyntraweb.sec;

import java.util.List;
import com.vyntraweb.simple.AuthGroup;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vyntraweb.simple.AuthGroup;

public interface AuthGroupRepo extends JpaRepository<AuthGroup, Long> {
    List<AuthGroup> findByUsername(String username);
}
