package com.example.simple;

import org.springframework.stereotype.Component;

@Component
public class lap {
	private String brand;

	public void getBrand() {
		System.out.print("compiling");
	}

	public void setBrand(String brand) {
		this.brand = "hp";
	}
	

}
