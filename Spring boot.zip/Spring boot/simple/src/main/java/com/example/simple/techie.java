package com.example.simple;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class techie {
	private int tid;
	private String tname;
	private String technology;
	@Autowired
	private lap lap1;
	public lap getLap1() {
		return lap1;
	}
	public void setLap1(lap lap1) {
		this.lap1 = lap1;
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public void disp()
	{
		System.out.print("i m here");
		lap1.getBrand();
	}

}
