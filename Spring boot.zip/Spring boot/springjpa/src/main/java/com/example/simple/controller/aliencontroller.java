package com.example.simple.controller;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.simple.alien;
import com.example.simple.dao.Alienrepo;
@RestController
public class aliencontroller {
	@Autowired
	Alienrepo arp;
	@RequestMapping("/addalien")
	
	public String home(alien a)
	{
		arp.save(a);
		return "alien.jsp";
	}
	
   @PostMapping("/aliens")
	
	public alien aliens(@RequestBody alien a)
	{
		arp.save(a);
		return a;
	}
   @DeleteMapping("/aliens/{aid}")
   @ResponseBody
	
	public String aliens(@PathVariable int aid)
	{
		alien a= arp.getOne(aid);
		arp.delete(a);
		return "deleted";
	}
   
   @PutMapping("/aliens")
	
	public alien saveorupdate(@RequestBody alien a)
	{
		arp.save(a);
		return a;
	}

 
	@GetMapping("/aliens")
	@ResponseBody
	public List<alien> fetchalien()
	{
		
	  return arp.findAll();
	}

}
