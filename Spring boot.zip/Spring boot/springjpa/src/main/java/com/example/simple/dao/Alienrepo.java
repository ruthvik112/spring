package com.example.simple.dao;

import com.example.simple.alien;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;


public interface Alienrepo  extends JpaRepository<alien,Integer>{

}
