package com.example.simple;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringdatarestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringdatarestApplication.class, args);
	}

}
