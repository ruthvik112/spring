insert into alien values(1,'ruthviksarma','python');
insert into alien values(2,'ruthvik','java');
insert into alien values(3,'sarma','python');
insert into alien values(4,'simba','java');
insert into alien values(5,'pumba','python');
insert into alien values(6,'ruthviksarma111','python');