package com.example.simple;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MywebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
