package com.vyntraweb.simple.dao;

import java.util.List;

import com.vyntraweb.simple.Vyntrauser;

public interface UserLoginDao {
	public void saveUser(Vyntrauser v);
	   public List<Vyntrauser> fetchingAllDetails();
	   public void deletingUser(Vyntrauser v);
	   public Vyntrauser fetchingUserDetailThroughId(Vyntrauser v);

}
