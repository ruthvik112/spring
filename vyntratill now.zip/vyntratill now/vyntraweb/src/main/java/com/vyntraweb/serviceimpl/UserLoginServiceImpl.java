package com.vyntraweb.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vyntraweb.services.UserLoginService;
import com.vyntraweb.simple.Vyntrauser;
import com.vyntraweb.simple.dao.UserLoginDao;

@Service
public class UserLoginServiceImpl implements UserLoginService {
	@Autowired
	private UserLoginDao userLoginDao;
	@Override
	public void saveUser(Vyntrauser v)
	{
		userLoginDao.saveUser(v);
	}
	@Override
	public List<Vyntrauser> fetchingAllDetails()
	{
		return userLoginDao.fetchingAllDetails();
	}
	@Override
	public void deletingUser(Vyntrauser v)
	{
		userLoginDao.deletingUser(v);
	}
	@Override
	public Vyntrauser fetchingUserDetailThroughId(Vyntrauser v)
	{
		return userLoginDao.fetchingUserDetailThroughId(v);
	}
	

}
