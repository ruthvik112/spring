package com.vyntraweb.simple.dao;

import com.vyntraweb.simple.products;
import org.springframework.data.jpa.repository.JpaRepository;
public interface productsrepo extends JpaRepository<products,Integer> {

}
