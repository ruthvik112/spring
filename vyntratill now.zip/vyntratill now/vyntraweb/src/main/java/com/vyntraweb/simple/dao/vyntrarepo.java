package com.vyntraweb.simple.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.vyntraweb.simple.Vyntrauser;

public interface vyntrarepo extends JpaRepository<Vyntrauser,Integer> {

}
