package com.vyntraweb.services;

import java.util.List;

import com.vyntraweb.simple.products;

public interface Productservice {
	public void saveProduct(products p);
    public List<products> fetchingProductDetails();
    public void deletingUser(products p);
    
}
