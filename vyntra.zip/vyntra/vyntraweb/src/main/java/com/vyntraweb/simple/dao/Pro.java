package com.vyntraweb.simple.dao;

import java.util.List;

import com.vyntraweb.simple.products;

public interface Pro {
	public void saveProduct(products p);
    public List<products> fetchingProductDetails();
    public void deletingUser(products p);

}
