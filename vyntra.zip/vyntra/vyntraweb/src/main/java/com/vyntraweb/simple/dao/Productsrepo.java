package com.vyntraweb.simple.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vyntraweb.simple.products;

public interface Productsrepo extends JpaRepository<products,Integer> {

}
