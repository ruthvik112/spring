package com.vyntraweb.simple.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vyntraweb.simple.Vyntrauser;

public interface Vyntrarepo extends JpaRepository<Vyntrauser,Integer> {
 List<Vyntrauser> findByUname(String uname);
}
