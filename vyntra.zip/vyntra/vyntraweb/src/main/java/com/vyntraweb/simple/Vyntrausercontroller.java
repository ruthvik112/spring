package com.vyntraweb.simple;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.vyntraweb.simple.Vyntrauser;
import com.vyntraweb.simple.dao.Productsrepo;
import com.vyntraweb.simple.dao.Vyntrarepo;



@Controller
public class Vyntrausercontroller {
	@Autowired
	Vyntrarepo u;
	@Autowired
	Productsrepo p;
	
	@GetMapping("/reg")
	public ModelAndView register()
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("reg.jsp");
		return mv;
	}
	@PostMapping("/reg")
	@ResponseBody
	public String register(Vyntrauser s)
	{
		u.save(s);
		return "Successfully Registered";
	}
	@RequestMapping("/login")
	public ModelAndView login(String uname,String password)
	{
		ModelAndView mv=new ModelAndView("login.jsp");
		System.out.print(u.findByUname(uname));
		System.out.print(uname);
		return mv;
	}
	
	@PostMapping("/addpro")
	public ModelAndView addpro(products k)
	{
		p.save(k);
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Addproducts.jsp");
		return mv;
	}
	
	@GetMapping("/addpro")
	public ModelAndView addpro()
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Addproducts.jsp");
		return mv;
	}
	
	@GetMapping("/listpro")
	public ModelAndView listpro()
	{
		ModelAndView mv=new ModelAndView();
		List<products> l=new ArrayList<>();
		for(products d:p.findAll())
		{
			l.add(d);
		}
		System.out.print(l);
		mv.addObject(l);
		mv.setViewName("Listproducts.jsp");
		return mv;
	}
}
